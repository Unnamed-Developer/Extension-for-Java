import java.io.File;
import java.io.IOException;

import Extension.*;
import Extension.Error.*;
import static Extension.Printer.out;

public class Instruction {
  public static void main(String[] args) throws Exception {
    // Extension 1 : Shorter print out
    int y = 5;
    String j = null;
    boolean k = true;
    char u = 'U';
    Integer[] m = { 9, 7, 0 };
    out.writeln(y);
    out.writeln(j);
    out.writeln(k);
    out.writeln(u);
    out.writeArray(m);
    // Extension 2 : Type Of Variable
    try {
      out.writeln(Command.TypeOf(k));
    } catch (TypeOfVariableException e) {
      e.printStackTrace();
    }
    {
      Object x = new Object();
      try {
        out.writeln(Command.TypeOf(x));
      } catch (TypeOfVariableException e) {
        e.printStackTrace();
      }
    }
    // Extension 3: CommandWriter
    Command.repeat(4, new CommandWriter() {

      @Override
      public void Writer() {
        out.writeln(1);
      }

    });
    out.writeln(Command.randomChar());
    out.writeln(Command.randomString(4, 6));
  }
}

class Instruction2 {
  public static void main(String[] args) {
    // Extension 4: Math Bonus
    out.writeln(MathBonus.gcd(2, 17) + MathBonus.lcm(9, 34));
    out.writeln(MathBonus.solveLinearEquation(3, 2, 7));
    out.writeln(MathBonus.solveQuadratic(0, 1, 3, 2));
    out.writeln("---------------------");
    out.writeln(MathBonus.fibonacciNumbers(20));
    out.writeln(MathBonus.primeNumbers(15));
    out.writeln(MathBonus.factorial(5));
    out.writeln("---------------------");
    out.writeln(MathBonus.analysis(174));
    out.writeln(MathBonus.isSquareNum(9));
    out.writeln(MathBonus.isPrimeNumber(16));
    out.writeln("---------------------");
    out.writeln(MathBonus.log(9, 27));
    out.writeln(MathBonus.root(17, 129140163, false));
    // Special case of root
    out.writeln("---------------------");
    out.writeln(MathBonus.root(2, -1, true));
    out.writeln("---------------------");
    out.writeln("Prove that there are at least 2 consecutive prime numbers that their difference is larger than 19");
    {
      int x = 2;
      int y = MathBonus.primeNumbers(x) - MathBonus.primeNumbers(x - 1);
      while (y <= 19) {
        x++;
        y = MathBonus.primeNumbers(x) - MathBonus.primeNumbers(x - 1);
      }
      out.writeln(MathBonus.primeNumbers(x) + ", " + MathBonus.primeNumbers(x - 1));
    }
  }
}

class Reciever {
  private static void sender() {
    Command.add("New", new CommandWriter() {

      @Override
      public void Writer() {
        out.writeln("Worked");
      }

    });
  }

  public static void main(String[] args) {
    sender();
    out.writeln("______________________________");
    Command.call("New");
  }
}

class FileWriter {
  public static void main(String[] args) throws IOException {
    File x = new File("name.cpp");
    FileCoder.write(x,
        "#include <iostream> \n using namespace std; \n \n int main() { \n \t cout << \"Hello World\"; \n \t return 0; \n }");
  }
}

