package Extension;

import java.util.Random;

import Extension.Error.TypeOfVariableException;

import java.util.HashMap;

public final class Command {
    /*--Command Reapeater--*/
    /**
     * @param time how many times the command can be repeated?
     * @param command to repeat
     * @since Extension 1.0
     */

    public static void repeat(int time, CommandWriter command) {
        for (int num = 0; num < time; num++) {
            command.Writer();
        }
    }

    /*--Sender & Reciever--*/
    public static HashMap<String, Runnable> listCommand = new HashMap<String, Runnable>();

    /**
     * @param m the key of the command
     * @param command
     * @since Extension 1.0
     */

    public static void add(String m, CommandWriter command) {
        listCommand.put(m, () -> command.Writer());
    }

    /**
     * @param m call the key of a command
     * @since Extension 1.0
     */

    public static void call(String m) {
        listCommand.get(m).run();
    }

    /**
     * @param m delete a key of a command
     * @since Extension 1.0
     */

    public void deleteCommand(String m) {
        listCommand.remove(m);
    }

    /*--Random--*/
    /**
     * @return random character
     * @since Extension 1.0
     */

    public static char randomChar() {
        Random rnd = new Random();
        char c = (char) ('a' + rnd.nextInt(26));
        return c;
    }

    /**
     * @param x
     * @param y
     * @return random number between x and y
     * @since Extension 1.0
     */

    public static int randomNum(int x, int y) {
        int num = (int) (Math.random() * (y + 1));
        while (num < x || num > y) {
            num = (int) (Math.random() * (y + 1));
        }
        return num;
    }

    /**
     * @param smallest
     * @param longest
     * @return random String between "smallest" and "longest" length
     * @since Extension 1.0
     */

    public static String randomString(int smallest, int longest) {
        int leftLimit = 48;
        int rightLimit = 122;
        int targetStringLength = randomNum(smallest, longest);
        Random random = new Random();
        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97)).limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
        return generatedString;
    }
    
    /**
     * @param object
     * @return TYPE
     * @throws TypeOfVariableException
     * @since Extension 1.0
     */

    public static String TypeOf(Object object) throws TypeOfVariableException {
        if (object instanceof String) {
            return "String";
        } else if (object instanceof Integer) {
            return "Integer";
        } else if (object instanceof Boolean) {
            return "Boolean";
        } else if (object instanceof Byte) {
            return "Byte";
        } else if (object instanceof Character) {
            return "Character";
        } else if (object instanceof Short) {
            return "Short";
        } else if (object instanceof Long) {
            return "Long";
        } else if (object instanceof Float) {
            return "Float";
        } else if (object instanceof Double) {
            return "Double";
        } else {
            throw new TypeOfVariableException("Cannot find the variable type of" + object.toString());
        }
    }
}