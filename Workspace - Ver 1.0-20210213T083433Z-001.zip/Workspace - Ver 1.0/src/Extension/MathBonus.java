package Extension;

import Extension.Constants.*;
import java.util.ArrayList;
import java.util.List;

public final class MathBonus {

  /**
   * @param a
   * @param b
   * @return greatest common divisor of 2 imput numbers
   * @since Extension 1.0
   */

  public static int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
  }

  /**
   * @param a
   * @param b
   * @return least common multiple of 2 input number
   * @since Extension 1.0
   */

  public static int lcm(int a, int b) {
    return (a * b) / gcd(a, b);
  }

  /**
   * y = ax + b
   * @param y
   * @param a
   * @param b
   * @return unknown number
   * @since Extension 1.0
   */

  public static String solveLinearEquation(double y, double a, double b) {
    // y = ax + b
    double x = (y - b) / a;
    int u = (int) x;
    if (u == x) {
      return String.valueOf(u);
    } else {
      return String.valueOf(x);
    }
  }
  /**
   * @param position
   * @return fibonacci number related to its position in the serial
   * @since Extension 1.0
   */

  public static int fibonacciNumbers(int position) {
    if (position == 0 || position == 1) return 1;
    return fibonacciNumbers(position - 1) + fibonacciNumbers(position - 2);
  }

  /**
   * @param position
   * @return prime number related to its position in the serial
   * @since Extension 1.0
   */

  public static int primeNumbers(int position) {
    position--;
    if (position == 0) return 2; else if (position == 1) return 3; else if (
      position < 0
    ) return -1; else {
      int p = 0;
      int n = 2;
      while (p < position) {
        n++;
        if (isPrimeNumber(n)) p++;
      }
      return n;
    }
  }

  /**
   * @param n
   * @return true or false if a number is a prime number
   * @since Extension 1.0
   */

  public static boolean isPrimeNumber(int n) {
    if (n < 2) {
      return false;
    }
    int squareRoot = (int) Math.sqrt(n);
    for (int i = 2; i <= squareRoot; i++) if (n % i == 0) return false;
    return true;
  }

  /**
   * @param x
   * @return the factorial of a number
   * @since Extension 1.0
   */

  public static int factorial(int x) {
    int gt = 1;
    {
      for (int i = 1; i <= x; i++) gt = gt * i;
      return gt;
    }
  }

  static List<String> list = new ArrayList<String>();

  /**
   * y = ax^2 + bx + c
   * @param y 
   * @param a
   * @param b
   * @param c
   * @return unknown number
   * @since Extension 1.0
   */

  public static List<String> solveQuadratic(
    double y,
    double a,
    double b,
    double c
  ) {
    // y = ax^2 + bx + c
    double k = c - y;
    double delta = b * b - 4 * a * k;
    double result;
    if (delta == 0) {
      result = -b / 2 / a;
      if (result == (int) result) {
        String r = String.valueOf((int) result);
        list.add(r);
        return list;
      } else {
        String r = String.valueOf(result);
        list.add(r);
        return list;
      }
    } else if (delta < 0) return null; else {
      result = (-b + Math.sqrt(delta)) / a / 2;
      double result1 = (-b - Math.sqrt(delta)) / a / 2;
      int resultInteger = (int) result;
      int resultInteger1 = (int) result1;
      if (resultInteger == result && resultInteger1 == result1) {
        String r1 = String.valueOf(resultInteger);
        String r2 = String.valueOf(resultInteger1);
        list.add(r1);
        list.add(r2);
        return list;
      } else if (resultInteger == result) {
        String r1 = String.valueOf(resultInteger);
        String r2 = String.valueOf(result1);
        list.add(r1);
        list.add(r2);
        return list;
      } else if (resultInteger1 == result1) {
        String r1 = String.valueOf(result);
        String r2 = String.valueOf(resultInteger1);
        list.add(r1);
        list.add(r2);
        return list;
      } else {
        String r1 = String.valueOf(result);
        String r2 = String.valueOf(result1);
        list.add(r1);
        list.add(r2);
        return list;
      }
    }
  }

  /**
   * @param i is a square num?
   * @return true or false if i is a square number
   * @since Extension 1.0
   */

  public static boolean isSquareNum(int i) {
    int a = (int) Math.sqrt(i);
    if (a * a == i) return true; else return false;
  }

  /**
   * @param n = a^x * b^y * ....
   * @return analysised number in a list
   * @since Extension 1.0
   */

  public static List<Integer> analysis(int n) {
    int i = 2;
    List<Integer> listNumbers = new ArrayList<Integer>();
    while (n > 1) {
      if (n % i == 0) {
        n = n / i;
        listNumbers.add(i);
      } else i++;
    }
    if (listNumbers.isEmpty()) {
      listNumbers.add(n);
    }
    return listNumbers;
  }

  /**
   * @param base the base
   * @param v base ^ x = v
   * @return exponent of 2 input numbers
   * @since Extension 1.0
   */

  public static double log(double base, double v) {
    // logbase(v)
    if (v == 1) return 0; else if (v > 0) return (
      Math.log(v) / Math.log(base)
    ); else if (
      base == 0 && v > 0
    ) return Constants.posiInf; else return Constants.NaN;
  }

  /**
   * @param exponent the exponent
   * @param v the power of 'exponent' of root(exponent, v)
   * @param round if true, round the number to integer format
   * @return base of 2 input numbers
   * @since Extension 1.0
   */

  public static String root(double exponent, double v, boolean round) {
    double n = 1 / exponent;
    if (v == 0) return String.valueOf(0); else if (
      v == 1
    ) return String.valueOf(1); else if (v < 0) {
      if (round) return (
        Math.round(Math.pow(v / -1, n)) + Constants.i
      ); else return Math.pow(v / -1, n) + Constants.i;
    } else if (exponent == 0) return String.valueOf(1); else {
      if (Math.pow(v, n) == (int) Math.pow(v, n)) return String.valueOf(
        (int) Math.pow(v, n)
      ); else if (round) return String.valueOf(
        Math.round(Math.pow(v, n))
      ); else return String.valueOf(Math.pow(v, n));
    }
  }

  /**
   * @param x the exponent
   * @return i ^ x (i is a complex number)
   * @since Extension 1.0
   */

  public static String iExp(int x) {
    if (x % 4 == 0) return String.valueOf(1); else if (
      x % 2 == 0
    ) return String.valueOf(-1); else if (
      x % 4 == 3
    ) return "-i"; else return "i";
  }
}
