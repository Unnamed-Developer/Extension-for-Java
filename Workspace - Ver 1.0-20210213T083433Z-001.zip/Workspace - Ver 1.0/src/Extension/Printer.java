package Extension;

public final class Printer {
  public static final Printer out = new Printer();
  public final String ln = "\n";
  public final String tab = "\t";
  public final String car_ret = "\r";
  public final String FormFeed = "\f";

  /**
   * @param x
   * @since Extension 1.0
   */

  public void write(Object x) {
    System.out.print(x);
  }

  /**
   * @param x
   * @since Extension 1.0
   */

  public void writeln(Object x) {
    write(x + out.ln);
  }

  /**
   * @param x
   * @since Extension 1.0
   */

  public void writeArray(Object[] x) {
    for (Object c : x)
      writeln(c);
  }

  /**
   * @param format
   * @param x
   * @since Extension 1.0
   */

  public void writeFormat(String format, Object x) {
    System.out.printf(format, x);
  }
}
