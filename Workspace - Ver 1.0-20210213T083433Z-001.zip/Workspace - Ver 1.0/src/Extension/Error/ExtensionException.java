package Extension.Error;

public class ExtensionException extends Exception {

    private static final long serialVersionUID = 1L;

    public ExtensionException() {
        super();
    }

    public ExtensionException(String str) {
        super(str);
    }

    public ExtensionException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExtensionException(Throwable cause) {
        super(cause);
    }

    protected ExtensionException(String message, Throwable cause,
                        boolean enableSuppression,
                        boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
