package Extension.Error;

public class TypeOfVariableException extends ExtensionException {

    private static final long serialVersionUID = 1L;

    public TypeOfVariableException() {
        super();
    }

    public TypeOfVariableException(String str) {
        super(str);
    }
}