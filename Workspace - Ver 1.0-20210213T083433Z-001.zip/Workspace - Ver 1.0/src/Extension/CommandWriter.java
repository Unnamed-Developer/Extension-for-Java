package Extension;

public abstract class CommandWriter {
    public abstract void Writer();
}
