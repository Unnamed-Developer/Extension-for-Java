package Extension;

import java.io.*;

public final class FileCoder extends File {
    private FileCoder(File parent, String child) {
        super(parent, child);
    }
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * @param file
     * @param writer
     * @throws IOException
     * @since Extension 1.0
     */
    
    public static void write(File file, String writer) throws IOException {
        FileWriter a = new FileWriter(file);
        a.write(writer);
        a.close();
    }
}
    
    

